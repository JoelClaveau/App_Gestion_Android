package com.example.myapplication

class Produit {


    var gtin: Int = 0
    var date : String = ""

    constructor(gtin: Int, date: String) {
        this.gtin = gtin
            this.date = date
    }

    constructor() {

    }
}
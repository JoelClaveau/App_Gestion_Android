package com.example.myapplication

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast
import java.util.ArrayList

val DATABASE_NAME="magasin"
val TABLE_NAME = "produit"
val COL_GTIN= "Gtin"
val COL_DATE = "Date_p"

class DataBase(var context: Context): SQLiteOpenHelper(context,DATABASE_NAME,null,1) {
        override fun onCreate(db: SQLiteDatabase?) {

            val createTable = "CREATE TABLE"+ TABLE_NAME+" (" +
                    COL_GTIN+"INTEGER PRIMARY KEY,"+
                    COL_DATE+ "VARCHAR(255),";

            db?.execSQL(createTable)
        }

        override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
            TODO("Not yet implemented")
        }

        fun insertData(produit : Produit){

            val db = this.writableDatabase
            var cv = ContentValues()
            cv.put(COL_GTIN, produit.gtin)
            cv.put(COL_DATE,produit.date)
            var result = db.insert(TABLE_NAME,null,cv)
            if(result == -1.toLong())
                Toast.makeText(context,"Failed",Toast.LENGTH_SHORT).show()
            else
                Toast.makeText(context,"Success", Toast.LENGTH_SHORT).show()
        }

    fun readData() : MutableList<Produit>{
        var list : MutableList<Produit> =  ArrayList()
        var db = this.readableDatabase
        val query = "Select * from" + TABLE_NAME +"Order by date_p"
        val result = db.rawQuery(query, null)
        if(result.moveToFirst()) {
            do {
                var produit = Produit()
                produit.gtin = result.getString(result.getColumnIndex(COL_GTIN)).toInt()
                produit.date = result.getString(result.getColumnIndex(COL_DATE))
                list.add(produit)
            } while (result.moveToNext())
        }
        result.close()
        db.close()
        return list
    }

    private fun <T> MutableList(): MutableList<T> {
    return MutableList()
    }


    fun updateData(){

            var db = this.readableDatabase
            val query = "Select * from" + TABLE_NAME
            val result = db.rawQuery(query, null)
            if(result.moveToFirst()) {
                do {
                var cv = ContentValues()
                    cv.put(COL_DATE,result.getInt(result.getColumnIndex(COL_DATE))+1)
                    db.update(TABLE_NAME, cv, COL_GTIN+"=? AND " + COL_DATE + "=?" ,
                        arrayOf(result.getString(result.getColumnIndex(COL_GTIN)),
                            result.getString(result.getColumnIndex(COL_DATE))))
                } while (result.moveToNext())
            }
                result.close()
                db.close()

        }


    }

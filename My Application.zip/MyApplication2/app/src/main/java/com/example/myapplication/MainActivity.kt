package com.example.myapplication
import android.content.Intent
import android.database.DatabaseErrorHandler
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*
import java.sql.*
import java.util.*
import android.widget.Toast
import android.widget.AdapterView
import android.widget.AdapterView.OnItemClickListener


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var context = this
        var db = DataBase(context)
        var btn_search = findViewById(R.id.btn_search) as EditText
        var btn_enter = findViewById(R.id.btn_enter) as SearchView
        var btn_gtin = findViewById(R.id.btn_gtin) as EditText
        var btn_date = findViewById(R.id.btn_date) as EditText
        var button = findViewById(R.id.button) as Button
        var listview = findViewById(R.id.listView) as ListView
        var tvResult = findViewById(R.id.tvResult) as TextView



        //Afficher les données de la table

        listView.setOnClickListener(){
            var data = db.readData()
            tvResult.text = ""
            for(i in 0..(data.size-1)){
                tvResult.append(data.get(i).gtin.toString() + "-----------------------------" + data.get(i).date+"\n")
            }
        }
    //insertion des champs
        button.setOnClickListener {

            if(btn_gtin.text.toString().length > 0 &&
                btn_date.text.toString().length > 0){

                var produit = Produit(btn_gtin.text.toString().toInt(), btn_date.text.toString())

                db.insertData(produit)

            }else{
                Toast.makeText(context,"Please Fill ALL Data's", Toast.LENGTH_SHORT).show()
            }
        }

        btn_update.setOnClickListener {

            db.updateData()
            listview.performClick()
        }



        btn_enter.setOnClickListener{

            val btn_search = btn_search.text;
        }


    }


}
